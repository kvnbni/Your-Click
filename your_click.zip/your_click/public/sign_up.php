<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
 <title>your_click Sign up</title>
 <?php
 $errors=array();
 $username="";
 if(isset($_POST['submit']))
 {
	$required_fields = array("username", "password");  
	validate_presences($required_fields);  //Checking if the username and password field was left blank
	$max_length=array('username'=>30,'password'=>100);
	validate_max_lengths($max_length);    //Checnking if the maximum field length is violated
	if(empty($errors))
	{
		$safe_user=mysql_prep($_POST['username']);  //To escape special characters in a string
		$safe_password=mysql_prep($_POST['password']);
		$safe_encrypted_password=password_encrypt($safe_password);
		
		if(check_if_user_exists($safe_user))
		{
			$errors['user_exists']="User already exists";
		}
		else
		{
			$query="INSERT INTO user (name, hashed_password) ";
			$query.="VALUES ('{$safe_user}','{$safe_encrypted_password}')";
			$result = mysqli_query($connection, $query);
		
			$id=(int)find_user_id($safe_user);
		
			$_SESSION["id"] = $id;
			$_SESSION["username"] = $safe_user;
			redirect_to("admin.php");
		}
		
	}
	
 }
 ?>
 
 <?php echo form_errors($errors); ?>
 <h2>Sign up</h2>
 <form action="sign_up.php" method="post">
 <p>Enter your username:
 <input type="text" name="username" value="<?php echo htmlentities($username); ?>" />
 </p>
 <p>Type in your password:
 <input type="password" name="password" value="" />
 </p>
 <input type="submit" name="submit" value="Submit" />
 </form>
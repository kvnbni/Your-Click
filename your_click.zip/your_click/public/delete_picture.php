<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php confirm_logged_in(); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php
	//bool unlink ( string $filename [, resource $context ] )
	$name_of_picture=$_GET["name"];
	$id=$_GET["id"];
	if (file_exists("images/".$name_of_picture))   //To check if the file exists or not
	{
		//echo "Picture deleted".$name_of_picture;
		$query = "DELETE FROM picture WHERE picture_id = '{$id}'";
		$result = mysqli_query($connection, $query);
		redirect_to("admin.php");
		
		
	}
	else
	{
		redirect_to("admin.php");
	}
	
?>

<?php include("../includes/layouts/footer.php"); ?>
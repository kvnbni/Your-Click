<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>

<html>
<head>
<link href="stylesheets/index.css" media="all" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
</head>
<title>your_click</title>
<body>

<h1>Welcome!!</h1>

<div align="Right">
<a href="sign_up.php">Sign Up</a>
<a href="login.php">Log in</a>
</div>
<table id="display">
	<th style="text-align: left; width: 400px;">Images</th>
	
	
		<?php // For public Navigation. I have deleted all the edit and delete options. People can just view the pictures that has been uploaded by users.?>
		<?php
			
			if (isset($_GET['page_num'])) 
			{
				$page_num = $_GET['page_num'];
			} 
			else 
			{
				$page_num = 1;
			}

			$total_images=find_count_of_images();   // The number of images in the database

			//To find the last page
			$images_per_page = 10;
			$last_page = ceil($total_images/$images_per_page);
			if($last_page==0)
			{
				$last_page=1;
			}

			//Check if the page is greater than last page or lesser than the first page 
			$page_num = (int)$page_num;
			if ($page_num > $last_page) 
			{
				$page_num = $last_page;
			} 
			if ($page_num < 1) 
			{
				$page_num = 1;
			}

			//offset,limit
			$limit = 'LIMIT ' .($page_num - 1) * $images_per_page .',' .$images_per_page;
			$images=find_all_image_names_index($limit);
			while ($image = mysqli_fetch_assoc($images))
			{
				$user=find_username_by_pictureid($image['picture_id']);
				$image_name="images/".$image['picture_name'];
				if(!empty($image_name))
				{
				
					$caption=find_caption_for_picture($image['picture_id']);
		?>
					<tr><td><figure><?php echo '<img src="'.$image_name.'" width="200" height="200"/>'."</br></br>"; ?>
					<figcaption display:block><?php echo htmlentities($caption)."</br> Uploaded by {$user}"; ?>
					</figcaption></figure></td>  <!--Echoing the image -->
				
		<?php
		
				}
			}
		
		?>
		       
</table>
<div align="Center">
<?php


if ($page_num == 1) 
{
	echo " FIRST PREV ";
} 
else 
{
	echo " <a href='{$_SERVER['PHP_SELF']}?page_num=1'>FIRST</a> "; //$_SERVER['PHP_SELF'] is the current script
	$prev_page = $page_num-1;
	echo " <a href='{$_SERVER['PHP_SELF']}?page_num=$prev_page'>PREV</a> ";
} 

echo " ( Page $page_num of $last_page ) ";

if ($page_num == $last_page) 
{
	echo " NEXT LAST ";
} 
else 
{
	$next_page = $page_num+1;
	echo " <a href='{$_SERVER['PHP_SELF']}?page_num=$next_page'>NEXT</a> ";
	echo " <a href='{$_SERVER['PHP_SELF']}?page_num=$last_page'>LAST</a> ";
} 
	
?>
</div>

<?php include("../includes/layouts/footer.php"); ?>

 
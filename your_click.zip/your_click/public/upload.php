<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>


<?php
	//$_FILES is the superglobal variable that holds the details of the file that was submitted using the POST method
	
	$image_name=basename($_FILES["image_to_be_uploaded"]["name"]);   //basename gives you the name of the file without the extension
	$user_id=$_SESSION['id'];
	$directory_to_upload_image="images/".$image_name;
	//echo $directory_to_upload_image;
	if(move_uploaded_file($_FILES["image_to_be_uploaded"]["tmp_name"], $directory_to_upload_image)) //tmp_name gives us the temporary location of the file on the server
	{
		$picture_name=$image_name;
		//$time_uploaded=time();
		$caption=$image_name;
		echo "Successfully moved";
		$query="INSERT INTO picture ";
		$query.="(user_id,caption,time_uploaded,picture_name) ";
		$query.="VALUES ";
		$query.="({$user_id},'{$caption}',now(),'{$picture_name}')"; //Usually we get these values from $_POST[] through input of a form
		$result=mysqli_query($connection,$query);
		redirect_to("admin.php");
	}
	else
	{
		
		redirect_to("admin.php");
	}
	
	
	
?>

<?php include("../includes/layouts/footer.php"); ?>
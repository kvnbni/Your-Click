<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php confirm_logged_in(); ?>
<?php 
$name_of_picture=$_GET["picture_name"]; 
$picture_id=$_GET["picture_id"];
?>
<title>your_click</title>
<head>
<link href="stylesheets/index.css" media="all" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
</head>

<?php
	
	//$name_of_picture=$_GET["picture"];
	$caption=$name_of_picture;
	
	if(isset($_POST["submit"])) //If form was submitted
	{
		
		
		$user_id=$_SESSION['id'];
		
		$caption=$_POST["caption"];
		//(user_id,caption,time_uploaded,picture_name)
		$query="UPDATE picture SET ";
		$query.="picture_id={$picture_id}, ";
		$query.="user_id={$user_id}, ";
		$query.="caption='{$caption}', ";
		$query.="time_uploaded=now(), ";
		$query.="picture_name='{$name_of_picture}' ";
		$query.="WHERE picture_id= {$picture_id} ";
		$query.="LIMIT 1";
		$result=mysqli_query($connection,$query);
		
		
		
		redirect_to("admin.php");
	}
	else
	{
		echo "";
	}
?>
<form action="edit_caption.php?picture_name=<?php echo urlencode($name_of_picture);?>&picture_id=<?php echo urlencode($picture_id);?>" method="post">

Caption for <?php echo $_GET["picture_name"];?>:</br>
<textarea name="caption" rows="20" cols="80" ></textarea>

</br><input type="submit" name="submit" value="Edit Caption" />
</form>




<?php include("../includes/layouts/footer.php"); ?>
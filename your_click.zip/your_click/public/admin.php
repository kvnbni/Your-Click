<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/validation_functions.php"); ?>
<?php confirm_logged_in(); ?>
<?php require_once("../includes/db_connection.php"); ?>
<link href="stylesheets/index.css" media="all" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
<html>
<title>your_click</title>
<div align="right">
<a href="logout.php">Logout</a>
</div>
<body>
<h1>Welcome <?php echo $_SESSION['username'];?>!!</h1>

<table id="display">
	<th style="text-align: left; width: 1000px;">Images</th>
	<th colspan="2" style="text-align: left;">Actions</th>
	
		
		<?php 
			
			if(empty($errors))
			{
				$user_id=(int)$_SESSION['id'];
				$images=find_all_image_names($user_id);
				while ($image = mysqli_fetch_assoc($images))
				{
					$image_name="images/".$image['picture_name'];
					//return $count['COUNT(picture_name)'];
					
					if(!empty($image_name))
					{
						
					
						$caption=find_caption_for_picture(basename($image['picture_id']));
		?>
						<tr><td><figure><?php echo '<img src="'.$image_name.'" width="200" height="200"/>'."</br></br>"; ?><figcaption><?php echo htmlentities($caption); ?>
						</figcaption></figure></td>  <!--Echoing the image -->
					
						<td><a href="delete_picture.php?name=<?php echo urlencode(basename($image['picture_name']));?>&id=<?php echo urlencode($image['picture_id'])?>" onclick="return confirm('Are you sure?');" >Delete</a></td><!--Echoing the delete tag -->
						<td>&emsp;<a href="edit_caption.php?picture_name=<?php echo urlencode(basename($image['picture_name']));?>&picture_id=<?php echo urlencode($image['picture_id'])?>">Edit Caption</a></td></tr>
						<?php
					
			
					
					}
				}
				//$images="images/".$images;
			}
			else
			{
				echo form_errors($errors);
			}
			
			
			
		?>
		
        
</table>

<form action="upload.php" method="post" enctype="multipart/form-data"><!-- enctype is the encryption type when we submit data and 
																		this value is required when we have a file upload control-->
	
	
    </br></br>Click to upload image <input type="file" name="image_to_be_uploaded">
	</br></br> <input type="submit" name="submit" value="Upload image">
</form>

<?php include("../includes/layouts/footer.php"); ?>

 

	</body>
</html>
<?php
//Close the connection
	if(isset($connection))
	{
		mysqli_close($connection);
	}
	
?>